#mvn dependency:copy-dependencies
java -cp target/dependency/hsqldb-2.3.3.jar org.hsqldb.util.DatabaseManager

