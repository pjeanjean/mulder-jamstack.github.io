package domain;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity
public class Person {
	
	@Id
	@GeneratedValue
	long id;
	
	String name, firstname;
	java.util.Date datebirth;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getFirstname() {
		return firstname;
	}
	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}
	public java.util.Date getDatebirth() {
		return datebirth;
	}
	public void setDatebirth(java.util.Date datebirth) {
		this.datebirth = datebirth;
	}
	

}
